# VOD Downloader

A simple script to download VODs from the Wubby TV archive.

## Installation

You can install this package using pip:
