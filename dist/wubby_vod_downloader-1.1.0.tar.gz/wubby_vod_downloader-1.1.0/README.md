# VOD Downloader

A simple script to download VODs from the Wubby TV archive.

## Installation

You can install this package using pip:

pip install wubby-vod-downloader

## Usage

Navigate to the directory you want to store the vods the script will create a new folder name vod_downloads and run

wubby-snatch
